package com.demo.jdbc;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class DatabaseMetaDataDemo {

	public static void main(String[] args) {
		ResourceBundle bundle=ResourceBundle.getBundle("db");
		String driver=bundle.getString("driver");
		String url=bundle.getString("url");
		String username=bundle.getString("username");
		String password=bundle.getString("password");
		
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		try(
		Connection con=DriverManager.getConnection(url,username,password);
			
				
		){
			DatabaseMetaData dbm=con.getMetaData();
			System.out.println("Product Name:"+dbm.getDatabaseProductName());
			System.out.println("Product Version:"+dbm.getDatabaseMajorVersion());
			System.out.println("Product Minor Version:"+dbm.getDatabaseMinorVersion());
			
		}catch(SQLException e) {
			e.printStackTrace();
		}

	}

}
