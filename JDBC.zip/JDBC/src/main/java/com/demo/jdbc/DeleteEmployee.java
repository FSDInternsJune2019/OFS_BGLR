package com.demo.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.Scanner;

public class DeleteEmployee {

	public static void main(String[] args) {
		ResourceBundle bundle=ResourceBundle.getBundle("db");
		String driver=bundle.getString("driver");
		String url=bundle.getString("url");
		String username=bundle.getString("username");
		String password=bundle.getString("password");
		Scanner scanner=new Scanner(System.in);
		System.out.print("Employee Id:");
		int employeeId=scanner.nextInt();
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		try(
		    Connection con=
		    DriverManager.getConnection(url,username,password);
			){
			PreparedStatement statement=
					con.prepareStatement("delete from employees "
							+ "where employee_id=?");
            statement.setInt(1, employeeId);
           int rows= statement.executeUpdate();
           if(rows>0)
        	   System.out.println("Employee record successfully deleted");
           else
        	   System.err.println("Error deleting");
		}catch(SQLException e) {
			e.printStackTrace();
		}
		

	}

}
