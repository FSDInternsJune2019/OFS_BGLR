package com.demo.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.Scanner;

public class RetrieveEmployeeById {

	public static void main(String[] args) {
		ResourceBundle bundle=ResourceBundle.getBundle("db");
		String driver=bundle.getString("driver");
		String url=bundle.getString("url");
		String username=bundle.getString("username");
		String password=bundle.getString("password");
		
		Scanner scanner=new Scanner(System.in);
		System.out.print("Employee ID:");
		int employeeId=scanner.nextInt();
		
		Connection con=null;
		try {
			con=DriverManager.getConnection(url,username,password);
			PreparedStatement statement=
					con.prepareStatement("select * from employees "
							+ "where employee_id=?");
			statement.setInt(1, employeeId);
			ResultSet resultSet=statement.executeQuery();
			System.out.println("=======salary details======");
			while(resultSet.next()) {
				String hireDate=resultSet.getString("hire_date");
				double salary=resultSet.getDouble("salary");
				double commPct=resultSet.getDouble("commission_pct");
				System.out.println(hireDate+"\t"+salary+"\t"+commPct);
			}
		}catch(SQLException e) {
			System.err.println("Error");
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		

	}

}
