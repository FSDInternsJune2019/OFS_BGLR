package com.demo.jdbc;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Scanner;

public class CreateEmployee {

	public static void main(String[] args) {
		ResourceBundle bundle=ResourceBundle.getBundle("db");
		String driver=bundle.getString("driver");
		String url=bundle.getString("url");
		String username=bundle.getString("username");
		String password=bundle.getString("password");
		
		Scanner scanner=new Scanner(System.in);
		System.out.print("Employee Id:");
		int employeeId=scanner.nextInt();
		System.out.print("First Name:");
		String firstName=scanner.next();
		System.out.print("Last Name:");
		String lastName=scanner.next();
		System.out.print("Email:");
		String email=scanner.next();
		System.out.print("Phone Number:");
		String phoneNumber=scanner.next();
		System.out.print("Hire date(DD-MM-YYYY)");
		String hireDate=scanner.next();
		System.out.print("Job Id:");
		String jobId=scanner.next();
		System.out.print("Salary:");
		double salary=scanner.nextDouble();
		System.out.print("Commission PCT:");
		double commPct=scanner.nextDouble();
		System.out.print("Manager id:");
		int managerId=scanner.nextInt();
		System.out.print("Department Id:");
		int departmentId=scanner.nextInt();
		
		//conversion of string into date
		Scanner scannerOfDate=new Scanner(hireDate)
				.useDelimiter("-");
		List<String> listOfDate=new ArrayList<>();
		while(scannerOfDate.hasNext()) {
			listOfDate.add(scannerOfDate.next());
		}
		java.sql.Date sqlDate=new java.sql.Date
				(Integer.parseInt(listOfDate.get(2)),
				Integer.parseInt(listOfDate.get(1)),
				Integer.parseInt(listOfDate.get(0)));
		
		Connection con=null;
		try {
			con=DriverManager.getConnection(url,username,password);
			PreparedStatement statement=
					con.prepareStatement("insert into employees values(?,?,?,?,?,?,?,?,?,?,?)");
		statement.setInt(1, employeeId);
		statement.setString(2, firstName);
		statement.setString(3, lastName);
		statement.setString(4, email);
		statement.setString(5, phoneNumber);
		// Format the Java Date 
		
		Date mysqlDate=Date.
				valueOf(LocalDate.of(Integer.parseInt(listOfDate.get(2)), 
						Integer.parseInt(listOfDate.get(1)),
						Integer.parseInt(listOfDate.get(0))));
		statement.setDate(6, mysqlDate);
		statement.setString(7, jobId);
		statement.setDouble(8,salary);
		statement.setDouble(9, commPct);
		statement.setInt(10, managerId);
		statement.setInt(11, departmentId);
		
		int rows=statement.executeUpdate();
		if(rows>0)
			System.out.println("Employee record inserted successfully");
		else
			System.err.println("Failed...");
		
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				con.close();
				scannerOfDate.close();
				scanner.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		

	}

}
