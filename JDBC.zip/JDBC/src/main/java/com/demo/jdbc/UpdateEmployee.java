package com.demo.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.Scanner;

public class UpdateEmployee {

	public static void main(String[] args) {
		ResourceBundle bundle=ResourceBundle.getBundle("db");
		String driver=bundle.getString("driver");
		String url=bundle.getString("url");
		String username=bundle.getString("username");
		String password=bundle.getString("password");
		try {
		Class.forName(driver);
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		Scanner scanner=new Scanner(System.in);
		System.out.print("Employee Id:");
		int employeeId=scanner.nextInt();
		System.out.print("Employee  New Salary:");
		double newSalary=scanner.nextDouble();
		try(
				Connection con=
				DriverManager.getConnection(url,username,password);
				
				
		){
			PreparedStatement statement=
					con.prepareStatement("update employees set salary=? where employee_id=?");
			
			statement.setDouble(1, newSalary);
			statement.setInt(2, employeeId);
			int rows=statement.executeUpdate();
			if(rows>0)
				System.out.println("Employee record updated");
			else
				System.out.println("Employee update failed");
		}catch(SQLException e) {
			e.printStackTrace();
		}

	}

}
