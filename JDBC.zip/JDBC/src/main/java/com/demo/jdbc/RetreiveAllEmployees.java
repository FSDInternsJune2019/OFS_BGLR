package com.demo.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

public class RetreiveAllEmployees {

	public static void main(String[] args) {
		//1. Read data from db.properties
		ResourceBundle bundle=ResourceBundle.getBundle("db");
		String driver=bundle.getString("driver");
		String url=bundle.getString("url");
		String username=bundle.getString("username");
		String password=bundle.getString("password");
		
		//2. Load driver
		
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//3. Open connection
		Connection con=null;
		try {
			con=DriverManager.getConnection(url,username,password);
			Statement statement=con.createStatement();
			ResultSet resultSet=
					statement.executeQuery("select * from employees");
			System.out.println("EmployeeID"+"\t"+"FirstName"+"\t"+"LastName");

			while(resultSet.next()) {
				int employeeId=resultSet.getInt("employee_id");
				String firstName=resultSet.getString("first_name");
				String lastName=resultSet.getString("last_name");
				System.out.println(employeeId+"\t"+firstName+"\t"+lastName);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		

	}

}
