package com.demo.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

public class ResultSetMetaDataDemo {

	public static void main(String[] args) {
		ResourceBundle bundle=ResourceBundle.getBundle("db");
		String driver=bundle.getString("driver");
		String url=bundle.getString("url");
		String username=bundle.getString("username");
		String password=bundle.getString("password");
		
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		try(
				Connection con=
				DriverManager.getConnection(url,username,password);
			){
			Statement statement=con.createStatement();
			ResultSet resultSet=
					statement.executeQuery("select * from employees");
			ResultSetMetaData rsm=resultSet.getMetaData();
			int columnCount=rsm.getColumnCount();
			System.out.println("Column Count:"+columnCount);
			for(int i=1;i<=columnCount;i++) {
				System.out.println("Column Name:"+rsm.getColumnName(i));
				System.out.println("Column Type:"+rsm.getColumnTypeName(i));
				System.out.println("Column label:"+rsm.getColumnLabel(i));
				
			}
			

		}catch(SQLException e) {
			e.printStackTrace();
		}
		

	}

}
