package com.oracle.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.EurekaClient;

@RestController
@RequestMapping("accountapi")
public class AccountController {
	@Autowired
	private RestTemplate restTemplate;
	@Autowired
	private EurekaClient discoveryClient;
	
	public String serviceUrl() {
		InstanceInfo instance=discoveryClient.getNextServerFromEureka("HR-SERVICE", 
				false);
		return instance.getHomePageUrl();
	}
	@GetMapping("accounts")
	public ResponseEntity<?> retrieveFromEmployeeService(){
		List list=restTemplate.getForObject(serviceUrl()+"/employeeapi/employees",
				List.class);
		return new ResponseEntity<List>(list,HttpStatus.OK);
	}

}
