package com.oracle.service;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import com.oracle.dto.EmployeesDTO;

@FeignClient(name = "HR-SERVICE")
public interface EmployeeClient {
	@GetMapping("/employeeapi/employees")
    List<EmployeesDTO> getEmployees();


}
