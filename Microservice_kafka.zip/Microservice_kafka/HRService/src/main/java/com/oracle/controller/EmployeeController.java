package com.oracle.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oracle.dto.EmployeesDTO;

@RestController
@RequestMapping("employeeapi")
public class EmployeeController {

	@GetMapping("employees")
	public ResponseEntity<?> get(){
		EmployeesDTO employeesDTO=new EmployeesDTO();
		employeesDTO.setEmpId(101);
		employeesDTO.setEmpName("sabbir");
		employeesDTO.setEmpSalary(45000);
		employeesDTO.setEmpDesignation("Trainer");
		List<EmployeesDTO> employeeList=Arrays.asList(employeesDTO);
		return new ResponseEntity<List<EmployeesDTO>>(employeeList,HttpStatus.OK);
		
	}
}
