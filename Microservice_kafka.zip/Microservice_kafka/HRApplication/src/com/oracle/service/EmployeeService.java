package com.oracle.service;

public class EmployeeService {
	
	public double computeTax(double salary) {
		return salary*0.01;
	}

}
