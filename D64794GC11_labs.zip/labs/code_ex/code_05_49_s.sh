#!/bin/bash
#To run this batch file:
#Start a terminal window
#cd /home/oracle/labs/code_ex
#code_05_49_s.sh
export CLASSPATH=/home/oracle/jdeveloper/modules/oracle.xdk_12.1.2/xmlparserv2.jar
#Classpath exported
java oracle.xml.parser.v2.oraxml -schema code_05_49_test.xml
