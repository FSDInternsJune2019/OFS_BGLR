connect oe/oe
SELECT * 
FROM XMLTABLE('fn:collection("oradb:/OE/WAREHOUSES/")/ROW/LOCATION_ID');

