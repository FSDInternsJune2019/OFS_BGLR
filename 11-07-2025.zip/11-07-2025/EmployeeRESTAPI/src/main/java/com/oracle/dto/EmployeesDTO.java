package com.oracle.dto;
import com.oracle.validation.ValidateEmpId;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class EmployeesDTO {
	@Schema(defaultValue = "0")
	@ValidateEmpId
	private int empId;
	@Schema(defaultValue = "Please type firstname and lastname")
	@Size(min = 3,max=10,message = "{com.oracle.dto.EmployeesDTO.empName.length}")
	private String empName;
	@Positive(message="{com.oracle.dto.EmployeesDTO.empSalary.valid}")
	private double empSalary;
	@Size(min=6,max=10,message="{com.oracle.dto.EmployeesDTO.empDesignation.valid}")
	private String empDesignation;
	public EmployeesDTO() {}
}
