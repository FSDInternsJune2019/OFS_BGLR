package com.oracle.controller;

import org.springframework.http.ResponseEntity;


import com.oracle.dto.EmployeesDTO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
@Tag(name = "Employee Resource Operations")
public interface EmployeeController {
	@Operation(description = "Get All Resource of type Employee")
	@ApiResponses(value = {@ApiResponse(description = "Successful in getting Resource of type Employee",responseCode = "200"),
	
			@ApiResponse(description = "No Resource of type Employee",responseCode = "404")
	})
	public ResponseEntity<?> get();
	
	public ResponseEntity<?>getPath(int empId);
	public ResponseEntity<?>getRequestParam(int empId);
	public ResponseEntity<?> create(EmployeesDTO employeesDTO);
	public String update(int empId,double empSalary);
	public String delete(int empId);

}
