package com.oracle.validation;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.oracle.dto.EmployeesDTO;
import com.oracle.service.EmployeesService;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
@Component
public class EmployeeIdValidator implements ConstraintValidator<ValidateEmpId,
Integer>{

	@Autowired
	private EmployeesService employeeService;
	
	@Override
	public boolean isValid(Integer value, ConstraintValidatorContext context) {
		EmployeesDTO employeeDTO=employeeService.getEmployeeDTO(value);
		if(employeeDTO!=null) {
			return false;
		}
		return true;
	}
}
