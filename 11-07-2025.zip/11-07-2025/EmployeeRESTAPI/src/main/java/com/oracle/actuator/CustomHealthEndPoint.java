package com.oracle.actuator;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.boot.actuate.endpoint.annotation.Selector;
import org.springframework.stereotype.Component;

@Component
@Endpoint(id = "custom-health")
public class CustomHealthEndPoint {
	@ReadOperation
	public CustomHealth health() {
		Map<String,Object> details=new HashMap<String,Object>();
		details.put("CustomHealthStatus", "Custom information about health");
		CustomHealth customHealth=new CustomHealth();
		customHealth.setHealthDetails(details);
		return customHealth;
	}
	

}
