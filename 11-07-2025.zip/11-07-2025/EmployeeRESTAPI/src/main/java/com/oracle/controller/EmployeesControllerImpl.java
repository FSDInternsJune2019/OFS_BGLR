package com.oracle.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.oracle.dto.EmployeesDTO;
import com.oracle.service.EmployeesService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("api")
@EnableAspectJAutoProxy
public class EmployeesControllerImpl implements EmployeeController{
	@Autowired
	private EmployeesService employeesService;

	@GetMapping("employees")
	@Override
	public ResponseEntity<?> get() {
		//int c=1/0;
		List<EmployeesDTO> employeesDTO=employeesService.getEmployeesDTO();
		if(!employeesDTO.isEmpty()) {
			return new ResponseEntity<List<EmployeesDTO>>(employeesDTO,HttpStatus.OK);
		}
		return new ResponseEntity<String>("No resource found",HttpStatus.NOT_FOUND);
	}

	@GetMapping("employees/{empId}")
	@Override
	public ResponseEntity<?> getPath(@PathVariable("empId") int empId) {
		EmployeesDTO employeesDTO=employeesService.getEmployeeDTO(empId);
		if(employeesDTO!=null)
			return new ResponseEntity<EmployeesDTO>(employeesDTO,HttpStatus.FOUND);
		return new ResponseEntity<String>("Employee Not Found",HttpStatus.NOT_FOUND);
	}
	@GetMapping("employeesparam")
	public ResponseEntity<?> getRequestParam(@RequestParam("empId")int empId){
		EmployeesDTO employeesDTO=employeesService.getEmployeeDTO(empId);
		if(employeesDTO!=null)
			return new ResponseEntity<EmployeesDTO>(employeesDTO,HttpStatus.FOUND);
		return new ResponseEntity<String>("Employee Not Found",HttpStatus.NOT_FOUND);
		
	}
	@PostMapping("employees")
	public ResponseEntity<?> create(@Valid @RequestBody EmployeesDTO employeesDTO){
		EmployeesDTO employeesDTOSaved=employeesService.saveEmployeeDTO(employeesDTO);
		if(employeesDTOSaved.getEmpId()!=0)
			return new ResponseEntity<EmployeesDTO>(employeesDTOSaved,HttpStatus.CREATED);
		else
			return new ResponseEntity<String>("Employee Resource creation failed",HttpStatus.BAD_REQUEST);
	}
	@PatchMapping("employees/{empId}/{empSalary}")
	public String update(@PathVariable("empId") int empId, @PathVariable("empSalary") double empSalary) {
		int outcome=employeesService.updateEmployeeDTO(empId, empSalary);
		if(outcome>0)
			return "Employee updated successfully";
		return "Employee updation failed";
	}
	@Override
	@DeleteMapping("employees/{empId}")
	public String delete(@PathVariable("empId") int empId) {
		return employeesService.deleteEmployee(empId);
	}
}














