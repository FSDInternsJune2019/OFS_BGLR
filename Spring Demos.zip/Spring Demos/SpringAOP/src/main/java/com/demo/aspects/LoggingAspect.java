package com.demo.aspects;


import java.time.LocalDateTime;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspect {
	Logger logger=Logger.getLogger("LoggingAspect");
	
	@Before(" execution(* com.demo.*.*.*(..))")
	public void beforeAdvice(JoinPoint joinPoint) {
		logger.log(Level.INFO, "Before advice applied on:"+joinPoint.getSignature().getName()+" "+LocalDateTime.now());
	}
	@After(" execution(* com.demo.*.*.*(..))")
	public void afterAdvice(JoinPoint joinPoint) {
		logger.log(Level.INFO, "After advice applied on:"+joinPoint.getSignature().getName()+" "+LocalDateTime.now());

	}

	@AfterReturning(pointcut =" execution(* com.demo.*.*.*(..))",returning ="result")
	public void afterReturning(JoinPoint joinPoint,Object result) {
		logger.log(Level.INFO,"After returning advice applied on:"+joinPoint.getSignature().getName()+" returned "+result);
	}
	@AfterThrowing(pointcut =" execution(* com.demo.*.*.*(..))",throwing  ="error")
	public void afterThrowing(JoinPoint joinPoint,Throwable error) {
		logger.log(Level.SEVERE,"After throwing advice applied on:"
	+joinPoint.getSignature().getName()
				+" threw exception "+error);
	}
	@Pointcut(value =" execution(* com.demo.beans.Bean1.x(..))" )
	public void getPointCut() {}
	
	   @Around("getPointCut()")
	   public Object aroundAdvice(ProceedingJoinPoint joinPoint) {
       logger.log(Level.INFO,"Around advice applied on:"
	   +joinPoint.getSignature().getName());
       int result=0;
       try {
		Object object=joinPoint.proceed();
		if(object instanceof Integer) {
			Integer integerO=(Integer)object;
			result=integerO*2;
		}
	} catch (Throwable e) {
		e.printStackTrace();
	}
       return result;
	   
		}
}
