package com.demo.main;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.demo.beans.Bean1;
import com.demo.configuration.BeanConfiguration;

public class SpringAOPDemo {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext ioc=
				new AnnotationConfigApplicationContext(BeanConfiguration.class);
		Bean1 bean1=(Bean1)ioc.getBean("bean1");
		int value=bean1.x();
		System.out.println(value);
	}

}
