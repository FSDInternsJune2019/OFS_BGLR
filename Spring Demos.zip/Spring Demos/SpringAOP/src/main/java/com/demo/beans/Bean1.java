package com.demo.beans;

import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Component;

@Component
@EnableAspectJAutoProxy
public class Bean1 {
	public Bean1() {
		System.out.println("--Bean1--");
	}

	public int x() {
		//int c=1/0;
		return 10;
	}
}
