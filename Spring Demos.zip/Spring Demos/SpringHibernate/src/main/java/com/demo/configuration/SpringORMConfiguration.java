package com.demo.configuration;

import java.util.Properties;

import org.apache.commons.dbcp2.BasicDataSource;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.support.TransactionTemplate;

import com.demo.entities.Employees;

@Configuration
@EnableTransactionManagement
@ComponentScan(basePackages = "com.demo.*")
@PropertySource({"classpath:db.properties"})
public class SpringORMConfiguration {
	
	@Autowired
	private Environment env;
	@Bean
	public BasicDataSource basicDataSource() {
		BasicDataSource basicDataSource=new BasicDataSource();
		basicDataSource.setDriverClassName(env.getProperty("driver"));
		basicDataSource.setUrl(env.getProperty("url"));
		basicDataSource.setUsername(env.getProperty("user_name"));
		basicDataSource.setPassword(env.getProperty("password"));
		return basicDataSource;
	}
	@Bean
	public Properties setHibernateProperties() {
		Properties properties=new Properties();
		properties.put("hibernate.dialect", "org.hibernate.dialect.MySQL5Dialect");
		properties.put("hibernate.hbm2ddl.auto", "update");
		properties.put("hibernate.show_sql", "true");
		properties.put("hibernate.current_session_context_class", "thread");
		return properties;
	}
	
	@Bean
	public SessionFactory sessionFactory() {
		org.hibernate.cfg.Configuration configuration=
				new org.hibernate.cfg.Configuration();
		configuration.addAnnotatedClass(Employees.class);
		
		StandardServiceRegistryBuilder serviceRegistryBuilder=
				new StandardServiceRegistryBuilder();
		serviceRegistryBuilder.applySetting(org.hibernate.cfg.Environment.DATASOURCE,
				basicDataSource());
		serviceRegistryBuilder.applySettings(configuration.getProperties());
		serviceRegistryBuilder.applySettings(setHibernateProperties());
		
		StandardServiceRegistry serviceRegistry=serviceRegistryBuilder
				.build();
		SessionFactory sessionFactory=
				configuration.buildSessionFactory(serviceRegistry);
		return sessionFactory;
	}
	
	@Bean
	public HibernateTemplate hibernateTemplate() {
		HibernateTemplate hibernateTemplate=new HibernateTemplate();
		hibernateTemplate.setSessionFactory(sessionFactory());
		hibernateTemplate.setCheckWriteOperations(false);
		return hibernateTemplate;
	}
	
	@Bean
	public HibernateTransactionManager hibernateTransactionManager() {
		HibernateTransactionManager hibernateTransactionManager=new HibernateTransactionManager();
		hibernateTransactionManager.setSessionFactory(sessionFactory());
		
		return hibernateTransactionManager;
	}
	@Bean
	public TransactionTemplate transactionTemplate() {
		TransactionTemplate transactionTemplate=new TransactionTemplate();
		transactionTemplate.setTransactionManager(hibernateTransactionManager());
		transactionTemplate.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
		return transactionTemplate;
	}



}
