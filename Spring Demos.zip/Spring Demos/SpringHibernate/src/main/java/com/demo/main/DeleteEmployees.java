package com.demo.main;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.demo.configuration.SpringORMConfiguration;
import com.demo.dao.EmployeesDAO;
import com.demo.entities.Employees;

public class DeleteEmployees {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext ioc=new AnnotationConfigApplicationContext
				(SpringORMConfiguration.class);

		EmployeesDAO employeeDAO=(EmployeesDAO)ioc.getBean("employeesDAOImpl");
		Employees employees=new Employees();
		employees.setEmployeeId(1010);
		employees.setEmployeeName("Prateek");
		employees.setEmployeeSalary(45000);
		employees.setEmployeeDesignation("Developer");
		boolean ifDeleted=employeeDAO.delete(employees);
		System.out.println("Employee deleted:"+ifDeleted);

	}

}
