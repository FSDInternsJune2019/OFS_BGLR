package com.demo.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateCallback;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import com.demo.entities.Employees;
@Repository
public class EmployeesDAOImpl implements EmployeesDAO {

	@Autowired
	private HibernateTemplate hibernateTemplate;
	@Autowired
	private TransactionTemplate transactionTemplate;
	
	@Override
	public List<Employees> findAll() {
		Transaction transaction=hibernateTemplate.getSessionFactory()
				.getCurrentSession().getTransaction();
		transaction.begin();
		List<Employees> employees=hibernateTemplate.execute(new HibernateCallback<List<Employees>>() {
			public List<Employees> doInHibernate(Session session) throws HibernateException {
				Query query=session.createQuery("from Employees e");
				List<Employees> employeeList=query.list();
				return employeeList;
			}
		});
		
		return employees;

	}

	@Override
	public Employees findById(int empId) {
		/*Transaction transaction=hibernateTemplate.getSessionFactory()
				.getCurrentSession().getTransaction();
		transaction.begin();*/
		return hibernateTemplate.load(Employees.class, empId);
	}

	@Override
	public boolean save(Employees employees) {
		Transaction transaction=hibernateTemplate.getSessionFactory()
				.getCurrentSession().getTransaction();
		transaction.begin();
		boolean result=transactionTemplate.execute(new TransactionCallback<Boolean>() {
			public Boolean doInTransaction(TransactionStatus status) {
			    try {
				
			    hibernateTemplate.save(employees);
			    transaction.commit();
			    return true;
			    }catch(Exception e) {
			    	e.printStackTrace();
			    	status.setRollbackOnly();
			    return false;
			    }
				
			}
			
		});
		return result;

	}

	@Override
	public boolean update(Employees employees) {
		Transaction transaction=hibernateTemplate.getSessionFactory().getCurrentSession()
				.getTransaction();
		transaction.begin();
		boolean result=transactionTemplate.execute(new TransactionCallback<Boolean>() {

			public Boolean doInTransaction(TransactionStatus status) {
				try {
                Employees employee=hibernateTemplate.load(Employees.class, 
                		employees.getEmployeeId());
				employee.setEmployeeSalary(employees.getEmployeeSalary());
				hibernateTemplate.merge(employee);
				transaction.commit();
				return true;
				}catch(Exception e) {
					status.setRollbackOnly();
					return false;
				}
			}
			
		});
		return result;

	}

	@Override
	public boolean delete(Employees employees) {
		Transaction transaction=hibernateTemplate.getSessionFactory().getCurrentSession()
				.getTransaction();
		transaction.begin();
		boolean result=transactionTemplate.execute(new TransactionCallback<Boolean>() {
			public Boolean doInTransaction(TransactionStatus status) {
				try {
				Employees employee=hibernateTemplate.load(Employees.class, 
						employees.getEmployeeId());
				hibernateTemplate.delete(employee);
				transaction.commit();
				return true;
				}catch(Exception e) {
					status.setRollbackOnly();
					return false;
				}
			}
		});
		return result;
	}

}
