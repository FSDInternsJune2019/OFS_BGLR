package com.demo.main;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.demo.configuration.SpringORMConfiguration;
import com.demo.dao.EmployeesDAO;

public class RetrieveEmployees {

	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext ioc=new AnnotationConfigApplicationContext(SpringORMConfiguration.class);

		EmployeesDAO employeesDAO=(EmployeesDAO)ioc.getBean("employeesDAOImpl");
		employeesDAO.findAll().forEach(System.out::println);
		
		System.out.println("******Retrieve Employees by Id******");
		System.out.println(employeesDAO.findById(1009));
		
		
	}

}
