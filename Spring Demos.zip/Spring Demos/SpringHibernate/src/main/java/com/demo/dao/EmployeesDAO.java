package com.demo.dao;

import java.util.List;

import com.demo.entities.Employees;

public interface EmployeesDAO {
	
	List<Employees> findAll();
	Employees findById(int empId);
	boolean save(Employees employees);
	boolean update(Employees employees);
	boolean delete(Employees employees);

}
