package com.demo.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.demo.beans.Bean1;
import com.demo.beans.Bean2;

import org.springframework.context.ApplicationContext;

public class ApplicationContextDemo {

	public static void main(String[] args) {
		
		ApplicationContext ioc1=
				new ClassPathXmlApplicationContext("applicationContext.xml");

		Bean1 bean11=(Bean1)ioc1.getBean("bean1");
		bean11.x();
		
		Bean1 bean12=(Bean1)ioc1.getBean(Bean1.class);
		bean12.x();
		
		if(bean11==bean12)
			System.out.println("bean11==bean12");
		
		Bean2 bean21=(Bean2)ioc1.getBean("bean2");
		Bean2 bean22=(Bean2)ioc1.getBean("bean2");
		if(bean21==bean22)
			System.out.println("bean21==bean22");
		else
			System.out.println("bean21!=bean22");
		
	}

}
