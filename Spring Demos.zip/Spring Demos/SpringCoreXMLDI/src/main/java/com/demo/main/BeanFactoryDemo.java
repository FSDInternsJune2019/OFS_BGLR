package com.demo.main;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.beans.factory.BeanFactory;

import com.demo.beans.Bean1;

public class BeanFactoryDemo {

	public static void main(String[] args) {
	
		Resource resource=new ClassPathResource("applicationContext.xml");
		BeanFactory ioc=new XmlBeanFactory(resource);
		
		Bean1 beanObj1=(Bean1)ioc.getBean("bean1");
		beanObj1.x();
		
		Bean1 beanObj2=ioc.getBean(Bean1.class);
		beanObj2.x();
		
		if(beanObj1==beanObj2)
			System.out.println("default scope:"+"singleton");
		
		Resource fileSystemResource=
				new FileSystemResource("D:\\MphasisIO\\beans.xml");
		BeanFactory ioc1=new XmlBeanFactory(fileSystemResource);
		Bean1 beanObj3=(Bean1)ioc1.getBean("bean1");
		beanObj3.x();

	}

}
