package com.demo.beans;

import org.springframework.beans.factory.DisposableBean;

public class PrototypeBean implements DisposableBean {
	
	public PrototypeBean() {
		System.out.println("--PrototypeBean--");
	}
	public void initMethod() {
		System.out.println("--PrototypeBean initMethod--");
	}
	public void customMethod() {
		System.out.println("--PrototypeBean customMethod--");
	}
	
	public void destroyMethod() {
		System.out.println("--PrototypeBean destroyMethod--");
	}
	@Override
	public void destroy() throws Exception {
		destroyMethod();
		
	}

}
