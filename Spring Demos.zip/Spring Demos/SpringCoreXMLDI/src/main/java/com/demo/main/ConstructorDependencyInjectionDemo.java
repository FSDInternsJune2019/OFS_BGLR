package com.demo.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.demo.beans.DataSourceImmutable;

import org.springframework.context.ApplicationContext;
public class ConstructorDependencyInjectionDemo {

	public static void main(String[] args) {
		
		ApplicationContext ioc=
				new ClassPathXmlApplicationContext("applicationContext.xml");

		DataSourceImmutable dataSource=
				(DataSourceImmutable)ioc.getBean("datasourceimmutable");
		System.out.println(dataSource);
		
		ApplicationContext ioc1=
				new FileSystemXmlApplicationContext("D:\\MphasisIO\\applicationContext.xml");
		DataSourceImmutable dataSource1=
				(DataSourceImmutable)ioc1.getBean("datasourceimmutable");
		System.out.println(dataSource1);
	}

}
