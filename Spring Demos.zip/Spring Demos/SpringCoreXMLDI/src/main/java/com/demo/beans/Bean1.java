package com.demo.beans;

public class Bean1 {

	public Bean1() {
		System.out.println("--Bean1 constructor--");
	}
	
	public void x() {
		System.out.println("--x--");
	}
	
	
	
}
