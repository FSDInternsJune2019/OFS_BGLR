package com.demo.beans;

public class Bean4 {
	
	public void bean4Method() {
		System.out.println("--bean4Method--");
	}

}
