package com.demo.main;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.demo.beans.PrototypeBean;

public class PrototypeBeanLifecycleDemo {

	public static void main(String[] args) {
		AbstractApplicationContext ioc=
				new ClassPathXmlApplicationContext("applicationContext.xml");
		PrototypeBean prototypeBean=(PrototypeBean)ioc.getBean("prototypebean");
		prototypeBean.customMethod();
		ioc.registerShutdownHook();
		ioc.close();
	}

}
