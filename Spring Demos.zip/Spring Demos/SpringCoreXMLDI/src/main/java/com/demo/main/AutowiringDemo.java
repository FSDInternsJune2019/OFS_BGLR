package com.demo.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.demo.beans.Bean3;

public class AutowiringDemo {

	public static void main(String[] args) {
		ApplicationContext ioc=
				new ClassPathXmlApplicationContext("applicationContext.xml");
     Bean3 bean3=(Bean3)ioc.getBean("bean3");
     bean3.bean3Method();

	}

}
