package com.demo.beans;

public class Bean3 {

	private Bean4 bean4;
	
	public Bean3(Bean4 bean4) {
		this.bean4=bean4;
	}
	
	public void bean3Method() {
		bean4.bean4Method();
	}
}
