package com.demo.main;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.demo.beans.SingletonBean;

public class SingletonBeanLifecyleDemo {

	public static void main(String[] args) {
		
		AbstractApplicationContext ioc=new ClassPathXmlApplicationContext("applicationContext.xml");
		SingletonBean singletonBean=
				(SingletonBean)ioc.getBean("singletonbean");
		singletonBean.customMethod();
		ioc.registerShutdownHook();
		ioc.close();

	}

}
