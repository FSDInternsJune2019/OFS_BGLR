package com.demo.beans;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.config.BeanPostProcessor;

public class BeanLifeCycleTracker implements BeanPostProcessor,DisposableBean,InitializingBean,BeanFactoryAware {

	private Map<String,Object> beansMap=new HashMap<>();
	private BeanFactory beanFactory;

	public BeanFactory getBeanFactory() {
		return beanFactory;
	}
	public void setBeanFactory(BeanFactory beanFactory) {
		this.beanFactory = beanFactory;
	}
	@Override
	public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
		System.out.println("Bean with name:"+beanName+" going for initialization ");
		return BeanPostProcessor.super.postProcessBeforeInitialization(bean, beanName);
	}@Override
	public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
		synchronized(beansMap) {
			beansMap.put(beanName, bean);
		}
		return bean;
	}
	@Override
	public void destroy() throws Exception {
		beansMap.forEach((k,v)->{
			if(beanFactory.isPrototype(k) && k.equals("prototypebean")) {
				if(v instanceof DisposableBean) {
					DisposableBean disposableBean=(DisposableBean)v;
					try {
						disposableBean.destroy();
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		});	
	}
	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("--afterPropertiesSet--");
		
	}
	
}
