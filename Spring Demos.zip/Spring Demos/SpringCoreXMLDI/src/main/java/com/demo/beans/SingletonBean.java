package com.demo.beans;

public class SingletonBean {
	
	public SingletonBean() {
		System.out.println("--SingletonBean--");
	}
	
	public void initMethod() {
		System.out.println("--SingletonBean initMethod--");
	}
	
	public void customMethod() {
		System.out.println("--SingletonBean Custom Method--");
	}
	
	public void destroyMethod() {
		System.out.println("--SingletonBean destroyMethod--");
	}
	
	

}
