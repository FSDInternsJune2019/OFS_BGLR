package com.demo.beans;

public class Bean2 {
	
	public Bean2() {
		System.out.println("--bean2--");
	}
	
	public void y() {
		System.out.println("--y--");
	}

}
