package com.demo.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.demo.entities.User;
@Repository
public class UserRepositoryImpl implements UserRepository {
	private static List<User> usersList=new ArrayList<>();

	@Override
	public List<User> findAll() {
		return usersList;
	}

	@Override
	public List<User> findByFirstName(String firstName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean save(User user) {
		return usersList.add(user);
	}

	@Override
	public boolean delete(User user) {
		// TODO Auto-generated method stub
		return false;
	}

}
