package com.demo.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.demo.dto.UserDTO;
import com.demo.service.UserService;

@Controller
public class UserController {
	
	@Autowired
	private UserService userService;
	
	
	@RequestMapping(value = "getUsers.htm",method = RequestMethod.GET)
	public ModelAndView getUser() {
		List<UserDTO> userDTOList=userService.findAllUserDTO();
		ModelAndView mv=new ModelAndView();
		mv.addObject("userDTOList",userDTOList);
		mv.setViewName("usersInfo");
		return mv;
		
	}

	@RequestMapping(value="postUser.htm",method = RequestMethod.POST)
	public ModelAndView postUser(@ModelAttribute("userdto") UserDTO userDTO) {
		ModelAndView mv=new ModelAndView();
		String outcome=userService.saveUserDTO(userDTO);
		if(outcome.equals("success")){
			mv.addObject("message","User added successfully");
		}else {
			mv.addObject("message","User addition failed");
		}
		mv.setViewName("userSave");
		return mv;
	}
	@ModelAttribute("userdto")
	public UserDTO defaultUserDTO() {
		UserDTO userDTO=new UserDTO();
		userDTO.setFirstName("Please type first name");
		userDTO.setLastName("Please type last name");
		return userDTO;
	}
	@RequestMapping(value = "loadForm.htm",method = RequestMethod.GET)
	public ModelAndView loadForm() {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("userForm");
		return mv;
	}
	
	@RequestMapping(value = "searchUser.htm",method=RequestMethod.GET)
	public ModelAndView searchForm() {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("searchForm");
		return mv;
	}
	@RequestMapping(value="getLastName.htm",method=RequestMethod.GET)
	public ModelAndView getUserByRequestParam(@RequestParam("firstName") String firstName) {
		List<UserDTO> usersDTO=userService.findAllUserDTO();
		List<UserDTO> searchedUserDTOList=usersDTO.stream()
		.filter((user)->user.getFirstName().equals(firstName))
		.collect(Collectors.toList());
		ModelAndView mv=new ModelAndView();
		mv.addObject("searchedUserDTOList",searchedUserDTOList);
		mv.setViewName("searchResult");
		return mv;
	}
	@RequestMapping(value ="/getLastNameByPath.htm/{firstName}",
			method=RequestMethod.GET)
	public ModelAndView getUserByPathParam(@PathVariable(name="firstName")String firstName) {
		List<UserDTO> usersDTO=userService.findAllUserDTO();
		List<UserDTO> searchedUserDTOList=usersDTO.stream()
		.filter((user)->user.getFirstName().equals(firstName))
		.collect(Collectors.toList());
		ModelAndView mv=new ModelAndView();
		mv.addObject("searchedUserDTOList",searchedUserDTOList);
		mv.setViewName("searchResult");
		return mv;
	}
}
