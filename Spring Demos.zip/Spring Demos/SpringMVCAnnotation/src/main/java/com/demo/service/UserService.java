package com.demo.service;

import java.util.List;

import com.demo.dto.UserDTO;

public interface UserService {
	
	public List<UserDTO> findAllUserDTO();
	public String saveUserDTO(UserDTO userDTO);

}
