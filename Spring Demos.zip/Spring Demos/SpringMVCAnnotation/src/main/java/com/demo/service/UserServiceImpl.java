package com.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.demo.dto.UserDTO;
import com.demo.entities.User;
import com.demo.repository.UserRepository;
@Service
@Scope("singleton")
public class UserServiceImpl implements UserService {
	@Autowired
	private UserRepository userRepository;

	@Override
	public List<UserDTO> findAllUserDTO() {
		List<User> userList=userRepository.findAll();
		List<UserDTO> userDTOlist=new ArrayList<>();
		userList.forEach(user->{
			UserDTO userDTO=new UserDTO();
			userDTO.setFirstName(user.getFirstName());
			userDTO.setLastName(user.getLastName());
			userDTOlist.add(userDTO);
		});
		return userDTOlist;
	}

	@Override
	public String saveUserDTO(UserDTO userDTO) {
		User user=new User();
		user.setFirstName(userDTO.getFirstName());
		user.setLastName(userDTO.getLastName());
		boolean ifSaved=userRepository.save(user);
		if(ifSaved)
			return "success";
		else
		return "fail";
	}

}
