package com.demo.repository;

import java.util.List;

import com.demo.entities.User;

public interface UserRepository {
	
	List<User> findAll();
	List<User> findByFirstName(String firstName);
	boolean save(User user);
	boolean delete(User user);
	

}
