package com.demo.main;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.demo.configuration.SpringJDBCConfiguration;
import com.demo.dao.EmployeesDAO;
import com.demo.entities.Employees;

public class SaveUpdateDeleteEmployeesDemo {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext ioc=new AnnotationConfigApplicationContext(SpringJDBCConfiguration.class);
		EmployeesDAO employeesDAO=(EmployeesDAO)ioc.getBean("employeesDAOImpl");

		Employees employees=new Employees();
		employees.setEmployeeId(1010);
		employees.setEmployeeName("Rohit");
		employees.setEmployeeSalary(45000);
		employees.setEmployeeDesignation("Trainer");
		
		boolean ifSaved=employeesDAO.save(employees);
		System.out.println("Saved?:"+ifSaved);
		
		employees.setEmployeeSalary(56000);
		boolean ifUpdated=employeesDAO.update(employees);
		System.out.println("Updated?:"+ifUpdated);
		
		boolean ifDeleted=employeesDAO.delete(employees);
		System.out.println("Deleted?:"+ifDeleted);
	}

}
