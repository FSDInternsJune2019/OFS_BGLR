package com.demo.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.demo.entities.Employees;
import com.demo.queries.EmployeesQueries;
@Repository
public class EmployeesDAOImpl implements EmployeesDAO {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	private RowMapper<Employees> rowMapper;
	@Autowired
	private EmployeesQueries queries;
	@Autowired
	private NamedParameterJdbcTemplate namedParameterjdbcTemplate;

	@Override
	public List<Employees> findAll() {
		return jdbcTemplate.query(queries.getSelectQuery(), rowMapper);
	}

	@Override
	public Employees findById(int empId) {
		
		//return jdbcTemplate.queryForObject(queries.getSelectByIdQuery(), new Object[] {empId}, rowMapper);
	
	String sql="select * from employees where emp_id=:id";
	Map<String,Integer> param=new HashMap<>();
	param.put("id", empId);
	return namedParameterjdbcTemplate.queryForObject(sql, param, rowMapper);
	}

	@Override
	public boolean save(Employees employees) {
		int rows=jdbcTemplate.update(queries.getInsertQuery(),
				new Object[] {
			employees.getEmployeeId(),
			employees.getEmployeeName(),
			employees.getEmployeeSalary(),
			employees.getEmployeeDesignation()
		});
		if(rows>0)
		return true;
		else
		return false;
	}

	@Override
	public boolean update(Employees employees) {
		int rows=
				jdbcTemplate.update(queries.getUpdateQuery(),
						new Object[] {
				employees.getEmployeeSalary(),
				employees.getEmployeeId()
		});
		if(rows>0)
		return true;
		else
		return false;
	}
	@Override
	public boolean delete(Employees employees) {
		int rows=jdbcTemplate.update(queries.getDeleteQuery(),new Object[] {
				employees.getEmployeeId()
		});
		if(rows>0)
		return true;
		else
		return false;
	}

}
