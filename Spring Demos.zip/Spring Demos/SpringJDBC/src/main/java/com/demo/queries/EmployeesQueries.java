package com.demo.queries;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class EmployeesQueries {
	@Value("${selectQuery}")
	private String selectQuery;
	
	@Value("${selectByIdQuery}")
	private String selectByIdQuery;
	
	@Value("${insertQuery}")
	private String insertQuery;
	
	@Value("${updateQuery}")
	private String updateQuery;
	
	@Value("${deleteQuery}")
	private String deleteQuery;

	public String getSelectQuery() {
		return selectQuery;
	}

	public String getSelectByIdQuery() {
		return selectByIdQuery;
	}

	public String getInsertQuery() {
		return insertQuery;
	}

	public String getUpdateQuery() {
		return updateQuery;
	}

	public String getDeleteQuery() {
		return deleteQuery;
	}

	
}
