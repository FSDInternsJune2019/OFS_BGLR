package com.demo.main;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.demo.configuration.SpringJDBCConfiguration;
import com.demo.dao.EmployeesDAO;
import com.demo.entities.Employees;

public class RetrieveEmployeesDemo {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext ioc=new AnnotationConfigApplicationContext(SpringJDBCConfiguration.class);
		EmployeesDAO employeesDAO=(EmployeesDAO)ioc.getBean("employeesDAOImpl");
		List<Employees> empList=employeesDAO.findAll();
		empList.forEach(System.out::println);
		
		System.out.println("****Employee by Id*****");
		Employees employee=employeesDAO.findById(1001);
		System.out.println(employee);
	}

}
