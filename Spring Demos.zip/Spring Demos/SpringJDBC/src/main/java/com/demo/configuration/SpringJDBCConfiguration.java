package com.demo.configuration;

import org.apache.commons.dbcp2.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

@Configuration
@PropertySource({"classpath:db.properties","classpath:sql.properties"})
@ComponentScan(basePackages = "com.demo.*")
public class SpringJDBCConfiguration {
	@Autowired
	private Environment env;
	
	@Bean
	public BasicDataSource getBasicDataSource() {
		BasicDataSource dataSource=new BasicDataSource();
		dataSource.setDriverClassName(env.getProperty("driver"));
		dataSource.setUrl(env.getProperty("url"));
		dataSource.setUsername(env.getProperty("user_name"));
		dataSource.setPassword(env.getProperty("password"));
		return dataSource;
	}
	@Bean(name = "jdbctemplate")
	public JdbcTemplate jdbcTemplate() {
		JdbcTemplate jdbcTemplate=new JdbcTemplate(getBasicDataSource());
		return jdbcTemplate;
	}
	@Bean(name="namedParameterjdbctemplate")
	public NamedParameterJdbcTemplate namedParameterJdbcTemplate() {
		NamedParameterJdbcTemplate namedParameter=
				new NamedParameterJdbcTemplate(getBasicDataSource());
		return namedParameter;
	}
	

}
