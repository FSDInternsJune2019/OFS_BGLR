package com.demo.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.demo.entities.Employees;
@Component
public class EmployeeMapper implements RowMapper<Employees> {

	@Override
	public Employees mapRow(ResultSet arg0, int arg1) throws SQLException {
		Employees employees=new Employees();
		employees.setEmployeeId(arg0.getInt(1));
		employees.setEmployeeName(arg0.getString(2));
		employees.setEmployeeSalary(arg0.getDouble(3));
		employees.setEmployeeDesignation(arg0.getString(4));
		return employees;
	}

}
