package com.demo.beans;

import java.util.Objects;

public class DataSource {
	
	public DataSource() {}
	
	private String driver;
	private String url;
	private String username;
	private String password;
	@Override
	public int hashCode() {
		return Objects.hash(driver, password, url, username);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DataSource other = (DataSource) obj;
		return Objects.equals(driver, other.driver) && Objects.equals(password, other.password)
				&& Objects.equals(url, other.url) && Objects.equals(username, other.username);
	}
	@Override
	public String toString() {
		return "DataSource [driver=" + driver + ", url=" + url + ", username=" + username + ", password=" + password
				+ "]";
	}
	public String getDriver() {
		return driver;
	}
	public void setDriver(String driver) {
		this.driver = driver;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	

}
