package com.demo.beans;

import org.springframework.stereotype.Component;

@Component
public class IntfImpl2 implements Intf {

	@Override
	public void x() {
		System.out.println("--impl2--");
	}

}
