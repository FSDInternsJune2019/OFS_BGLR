package com.demo.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.demo.beans.DataSource;

public class SpelDemo {

	public static void main(String[] args) {
		ApplicationContext ioc=
				new ClassPathXmlApplicationContext("applicationContext.xml");

		DataSource dataSource=(DataSource)ioc.getBean("datasource");
		System.out.println(dataSource);
		
	}

}
