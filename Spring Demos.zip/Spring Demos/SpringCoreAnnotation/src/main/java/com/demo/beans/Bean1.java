package com.demo.beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class Bean1 {
	
	@Autowired@Qualifier("intfImpl2")
	private Intf intf;

	public Bean1() {
		System.out.println("--Bean 1--");
	}
	public void bean1Method() {
		intf.x();
	}
	
}
