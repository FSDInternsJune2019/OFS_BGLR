package com.demo.customannotations;

import java.lang.reflect.Method;

public class AnnotationProcessingDemo {

	public static void main(String[] args) {
		
		Class<MyClass> myClassData=MyClass.class;
		TR9 tr9=(TR9)myClassData.getAnnotation(TR9.class);
		if(tr9!=null)
			System.out.println("@TR9 applied on MyClass");
		else
			System.out.println("@TR9 not applied on MyClass");
		
		try {
			Method x=myClassData.getMethod("x");
			TR9Method tr9Method=(TR9Method)x.getAnnotation(TR9Method.class);
			System.out.println("topic:"+tr9Method.topic());
		} catch (NoSuchMethodException | SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
