package com.demo.beans;

public interface Intf {
public void x();
}
