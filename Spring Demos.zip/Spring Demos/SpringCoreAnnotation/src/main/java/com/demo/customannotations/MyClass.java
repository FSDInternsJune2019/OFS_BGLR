package com.demo.customannotations;

@TR9
public class MyClass {

	@TR9Method(topic = "Spring Framework")
	public void x() {}
}
