package com.demo.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.Scope;

import com.demo.beans.Bean1;

@Configuration
@PropertySource({"classpath:db.properties"})
@ComponentScan(basePackages = "com.demo.*")
public class BeanConfiguration {
	
	@Bean(name = "bean1")
	@Scope("prototype")
	@Lazy
	public Bean1 getBean1() {
		Bean1 bean1=new Bean1();
		return bean1;
	}

}
