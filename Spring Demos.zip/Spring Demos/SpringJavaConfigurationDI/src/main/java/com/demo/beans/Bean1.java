package com.demo.beans;

public class Bean1 {
	
	public Bean1() {
		System.out.println("--Bean 1--");
	}
	public void bean1Method() {
		System.out.println("--bean1Method--");
	}

}
