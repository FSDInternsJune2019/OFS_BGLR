package com.demo.main;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.demo.beans.Bean1;
import com.demo.beans.DataSource;
import com.demo.configuration.BeanConfiguration;

public class JavaConfigurationDemo {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext ioc=
				new AnnotationConfigApplicationContext(BeanConfiguration.class);
		Bean1 bean1=(Bean1)ioc.getBean("bean1");
		bean1.bean1Method();
		
		DataSource dataSource=(DataSource)ioc.getBean("dataSource");
		System.out.println(dataSource);

	}

}
