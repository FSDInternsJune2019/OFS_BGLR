package com.oracle.service;

import java.util.List;

import com.oracle.dto.EmployeesDTO;

public interface EmployeesService {
	
	public List<EmployeesDTO> getEmployeesDTO();
	public EmployeesDTO getEmployeeDTO(int empId);
	public EmployeesDTO saveEmployeeDTO(EmployeesDTO employeesDTO);
	public int updateEmployeeDTO(int empId,double empSalary);
	public String deleteEmployee(int empId);

}
