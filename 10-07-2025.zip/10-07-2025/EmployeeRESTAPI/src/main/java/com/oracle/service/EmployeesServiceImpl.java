package com.oracle.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.oracle.dto.EmployeesDTO;
import com.oracle.entities.Employees;
import com.oracle.repository.EmployeeRepository;

@Service
public class EmployeesServiceImpl implements EmployeesService{
	@Autowired
	private EmployeeRepository employeeRepository;

	@Override
	public List<EmployeesDTO> getEmployeesDTO() {
		
		Iterable<Employees> employeesList=employeeRepository.findAll();
		List<EmployeesDTO> employeesDTOList=new ArrayList<>();
		for(Employees employees:employeesList) {
			EmployeesDTO employeesDTO=new EmployeesDTO();
			employeesDTO.setEmpId(employees.getEmpId());
			employeesDTO.setEmpName(employees.getEmpName());
			employeesDTO.setEmpSalary(employees.getEmpSalary());
			employeesDTO.setEmpDesignation(employees.getEmpDesignation());
			employeesDTOList.add(employeesDTO);
		}
		return employeesDTOList;
	}

	@Override
	public EmployeesDTO getEmployeeDTO(int empId) {
		Optional<Employees> employeesOptional= employeeRepository.findById(empId);
		if(employeesOptional.isPresent()) {
			Employees employees=employeesOptional.get();
			EmployeesDTO employeesDTO=new EmployeesDTO();
			employeesDTO.setEmpId(employees.getEmpId());
			employeesDTO.setEmpName(employees.getEmpName());
			employeesDTO.setEmpSalary(employees.getEmpSalary());
			employeesDTO.setEmpDesignation(employees.getEmpDesignation());
			return employeesDTO;
		}
		return null;
	}

	@Override
	public EmployeesDTO saveEmployeeDTO(EmployeesDTO employeesDTO) {
		
		Employees employees=new Employees();
		employees.setEmpId(employeesDTO.getEmpId());
		employees.setEmpName(employeesDTO.getEmpName());
		employees.setEmpSalary(employeesDTO.getEmpSalary());
		employees.setEmpDesignation(employeesDTO.getEmpDesignation());
		Employees employeesSaved=employeeRepository.save(employees);
		
		EmployeesDTO employeesDTOSaved=new EmployeesDTO();
		employeesDTOSaved.setEmpId(employeesSaved.getEmpId());
		employeesDTOSaved.setEmpName(employeesSaved.getEmpName());
		employeesDTOSaved.setEmpSalary(employeesSaved.getEmpSalary());
		employeesDTOSaved.setEmpDesignation(employeesSaved.getEmpDesignation());
		return employeesDTOSaved;
	}

	@Override
	@Transactional
	public int updateEmployeeDTO(int empId, double empSalary) {
		return employeeRepository.update(empId, empSalary);
	}

	@Override
	public String deleteEmployee(int empId) {
		try {
		employeeRepository.deleteById(empId);
		return "success";
		}catch(Exception e) {
			return "fail";
		}
	}

}







