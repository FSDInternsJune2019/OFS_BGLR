package com.demo.entities;

import java.util.Objects;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="consultant_table")
public class Consultant {

	@Id
	@Column(name="consultant_id")
	private int consultantId;
	@Column(name="consultant_name")
	private String consultantName;
	@OneToOne(targetEntity = Project.class,fetch = FetchType.EAGER,cascade = 
			CascadeType.ALL)
	private Project project;
	
	public Consultant() {}

	public int getConsultantId() {
		return consultantId;
	}

	public void setConsultantId(int consultantId) {
		this.consultantId = consultantId;
	}

	public String getConsultantName() {
		return consultantName;
	}

	public void setConsultantName(String consultantName) {
		this.consultantName = consultantName;
	}

	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	@Override
	public int hashCode() {
		return Objects.hash(consultantId, consultantName, project);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Consultant other = (Consultant) obj;
		return consultantId == other.consultantId && Objects.equals(consultantName, other.consultantName)
				&& Objects.equals(project, other.project);
	}

	@Override
	public String toString() {
		return "Consultant [consultantId=" + consultantId + ", consultantName=" + consultantName + ", project="
				+ project + "]";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
