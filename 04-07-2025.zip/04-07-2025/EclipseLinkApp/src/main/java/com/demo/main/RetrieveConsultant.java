package com.demo.main;

import com.demo.entities.Consultant;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class RetrieveConsultant {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA");
		EntityManager em=emf.createEntityManager();
		Consultant consultant=em.find(Consultant.class, 1001);
		System.out.println(consultant);

	}

}
