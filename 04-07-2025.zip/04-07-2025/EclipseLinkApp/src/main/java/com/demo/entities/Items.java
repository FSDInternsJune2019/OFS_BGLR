package com.demo.entities;

import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="items_table")
public class Items {
	@Id
	@Column(name="item_id")
	private int itemId;
	@Column(name="item_description")
	private String itemDescription;
	
	public Items() {}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public String getItemDescription() {
		return itemDescription;
	}

	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}

	@Override
	public int hashCode() {
		return Objects.hash(itemDescription, itemId);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Items other = (Items) obj;
		return Objects.equals(itemDescription, other.itemDescription) && itemId == other.itemId;
	}

	@Override
	public String toString() {
		return "Items [itemId=" + itemId + ", itemDescription=" + itemDescription + "]";
	}
	
	

}
