package com.demo.main;

import com.demo.entities.Employees;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;

public class RemoveEmployee {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA");
		EntityManager em=emf.createEntityManager();
		Employees employee=em.find(Employees.class, 1001);
		EntityTransaction et=em.getTransaction();
		et.begin();
		em.remove(employee);
		et.commit();
		em.close();

	}

}
