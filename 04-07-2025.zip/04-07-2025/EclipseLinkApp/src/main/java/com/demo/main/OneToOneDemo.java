package com.demo.main;

import com.demo.entities.Consultant;
import com.demo.entities.Project;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;

public class OneToOneDemo {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA");
		EntityManager em=emf.createEntityManager();
		Project project=new Project();
		project.setProjectCode("P001");
		project.setClientName("HDFC");
		
		Consultant consultant=new Consultant();
		consultant.setConsultantId(1001);
		consultant.setConsultantName("Sabbir");
		
		consultant.setProject(project);
		
		EntityTransaction et=em.getTransaction();
		et.begin();
		em.persist(consultant);
		et.commit();
		em.close();
		
		
		

	}

}
