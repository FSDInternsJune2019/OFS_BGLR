package com.demo.entities;

import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="project_table")
public class Project {
	@Id
	@Column(name="project_code")
	private String projectCode;
	@Column(name="client_name")
	private String clientName;
	
	public Project() {}

	public String getProjectCode() {
		return projectCode;
	}

	public void setProjectCode(String projectCode) {
		this.projectCode = projectCode;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	@Override
	public int hashCode() {
		return Objects.hash(clientName, projectCode);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Project other = (Project) obj;
		return Objects.equals(clientName, other.clientName) && Objects.equals(projectCode, other.projectCode);
	}

	@Override
	public String toString() {
		return "Project [projectCode=" + projectCode + ", clientName=" + clientName + "]";
	}
	
	

}
