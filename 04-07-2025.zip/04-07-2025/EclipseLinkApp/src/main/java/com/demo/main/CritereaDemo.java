package com.demo.main;

import java.util.List;

import com.demo.entities.Employees;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;

public class CritereaDemo {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA");
		EntityManager em=emf.createEntityManager();
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery cq = cb.createQuery();
		Root e = cq.from(Employees.class);
		cq.where(cb.greaterThan(e.get("empSalary"), 10000));
		Query query = em.createQuery(cq);
		List<Employees> employeesList = query.getResultList();
		employeesList.forEach(System.out::println);

	}

}







