package com.demo.main;

import java.util.List;

import com.demo.entities.Employees;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

public class RetrieveEmployees {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA");
		EntityManager em=emf.createEntityManager();
		Query query=em.createQuery("select o from Employees o");
		List<Employees> employeesList=query.getResultList();
		employeesList.forEach(System.out::println);
		em.close();
		

	}

}
