package com.demo.entities;

import java.util.List;
import java.util.Objects;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="customers_table")
public class Customers {
	@Id
	@Column(name="cust_id")
	private int custId;
	@Column(name="cust_name")
	private String custName;
	@OneToMany(targetEntity = Orders.class,cascade = CascadeType.ALL,
			fetch=FetchType.EAGER)
	private List<Orders> orders;
	
	public Customers() {}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public List<Orders> getOrders() {
		return orders;
	}

	public void setOrders(List<Orders> orders) {
		this.orders = orders;
	}

	@Override
	public String toString() {
		return "Customers [custId=" + custId + ", custName=" + custName + ", orders=" + orders + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(custId, custName, orders);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customers other = (Customers) obj;
		return custId == other.custId && Objects.equals(custName, other.custName)
				&& Objects.equals(orders, other.orders);
	}
	
	

}
