package com.demo.main;

import com.demo.entities.Employees;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

public class UpdateEmployees {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		et.begin();
		Query query=em.createNamedQuery("UpdateEmployee");
		query.setParameter("salary", 67000);
		query.setParameter("id", 1001);
		int employeeUpdate=query.executeUpdate();
		System.out.println("Employee updated:"+employeeUpdate);
		et.commit();
		Employees employee=em.find(Employees.class, 1001);
		System.out.println(employee);

	}

}







