package com.demo.main;

import java.util.Arrays;
import java.util.List;

import com.demo.entities.Customers;
import com.demo.entities.Items;
import com.demo.entities.Orders;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;

public class OneToManyDemo {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA");
		EntityManager em=emf.createEntityManager();
		
		Items item1=new Items();
		item1.setItemId(101);
		item1.setItemDescription("item-1");
		
		Items item2=new Items();
		item2.setItemId(102);
		item2.setItemDescription("item-2");
		
		List<Items> itemList1=Arrays.asList(item1,item2);
		
		Items item3=new Items();
		item3.setItemId(103);
		item3.setItemDescription("item-3");
		
		Items item4=new Items();
		item4.setItemId(104);
		item4.setItemDescription("item-4");
		
		List<Items> itemList2=Arrays.asList(item3,item4);
		
		Orders order1=new Orders();
		order1.setItems(itemList1);
		order1.setOrderId("ODR01");
		order1.setOrderDescription("Order-1 description");
		
		Orders order2=new Orders();
		order2.setItems(itemList2);
		order2.setOrderId("ODR02");
		order2.setOrderDescription("Order-2 description");
		
		List<Orders> ordersList=Arrays.asList(order1,order2);
		Customers customer=new Customers();
		customer.setCustId(1001);
		customer.setCustName("sabbir");
		customer.setOrders(ordersList);
		
		EntityTransaction et=em.getTransaction();
		et.begin();
		em.persist(customer);
		et.commit();
		em.close();
		
		

	}

}
