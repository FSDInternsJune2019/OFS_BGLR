package com.demo.main;

import com.demo.entities.Employees;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;

public class PersistEmployees {

	public static void main(String[] args) {
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA");
		
		//1. Transient state
		Employees employees=new Employees();
		employees.setEmpId(1001);
		employees.setEmpName("sabbir");
		employees.setEmpSalary(45000);
		employees.setEmpDesignation("Trainer");
		
		//2.Persistent state
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		et.begin();
		em.persist(employees);
		et.commit();
		em.close();
		

	}

}
