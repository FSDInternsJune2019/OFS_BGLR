package com.demo.entities;

import java.util.List;
import java.util.Objects;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="orders_table")
public class Orders {
	@Id
	@Column(name="order_id")
	private String orderId;
	@Column(name="order_description")
	private String orderDescription;
	@OneToMany(targetEntity = Items.class,fetch = FetchType.EAGER,cascade=CascadeType.ALL)
	private List<Items> items;
	
	public Orders() {}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getOrderDescription() {
		return orderDescription;
	}

	public void setOrderDescription(String orderDescription) {
		this.orderDescription = orderDescription;
	}

	public List<Items> getItems() {
		return items;
	}

	public void setItems(List<Items> items) {
		this.items = items;
	}

	@Override
	public String toString() {
		return "Orders [orderId=" + orderId + ", orderDescription=" + orderDescription + ", items=" + items + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(items, orderDescription, orderId);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Orders other = (Orders) obj;
		return Objects.equals(items, other.items) && Objects.equals(orderDescription, other.orderDescription)
				&& Objects.equals(orderId, other.orderId);
	}
	
	

}









