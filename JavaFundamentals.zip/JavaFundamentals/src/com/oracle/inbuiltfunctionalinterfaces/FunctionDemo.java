package com.oracle.inbuiltfunctionalinterfaces;

import java.util.function.Function;

public class FunctionDemo {

	public static void main(String[] args) {
		
		Function<String,Integer> functionToInt1=(s)->Integer.parseInt(s);
		System.out.println("functionToInt->"+(functionToInt1.apply("10")+10));
		
		Function<String,Integer> functionToInt2=Integer::parseInt;
		System.out.println("functionToInt2->"+(functionToInt2.apply("10")+10));
		

	}

}
