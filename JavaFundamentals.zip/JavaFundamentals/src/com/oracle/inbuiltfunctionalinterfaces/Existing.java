package com.oracle.inbuiltfunctionalinterfaces;

public class Existing {
	
	public Existing() {}
	
	public void lower(String data) {
		System.out.println(data.toLowerCase());
	}
	
	public static void upper(String data) {
		System.out.println(data.toUpperCase());
	}

}
