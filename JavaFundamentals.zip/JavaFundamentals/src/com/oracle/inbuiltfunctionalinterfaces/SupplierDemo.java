package com.oracle.inbuiltfunctionalinterfaces;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Supplier;

public class SupplierDemo {

	public static void main(String[] args) throws InterruptedException, ExecutionException {
		
		Supplier<String> companyName=()->{
			return "Oracle Financial Services";
		};
		
		System.out.println("Company Name:"+companyName.get());
		
		ExecutorService es=Executors.newFixedThreadPool(10);
		
		Integer o=10;
		Supplier<Integer> supplierOfInteger= o::intValue;
		
		System.out.println("supplierOfInteger->"+supplierOfInteger.get());
		
		System.out.println("Thread:"+Thread.currentThread().getName());

		
		Supplier<String> thread1ReturnVal=()->{
			System.out.println("Thread:"+Thread.currentThread().getName());

		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		
		return "Thread-1 Executed";};
		CompletableFuture<String> completableFuture1=CompletableFuture.supplyAsync(thread1ReturnVal,es);
		
		String outputOfThread1=completableFuture1.get();
		System.out.println("outputOfThread1->"+outputOfThread1);
		
		CompletableFuture<String> completableFuture2=CompletableFuture.supplyAsync(()->{
			System.out.println("Thread:"+Thread.currentThread().getName());
			return "Thread-2 Executed";
		},es);
		String outputOfThread2=completableFuture2.get();
		System.out.println("outputOfThread2->"+outputOfThread2);
		
	}

}

























