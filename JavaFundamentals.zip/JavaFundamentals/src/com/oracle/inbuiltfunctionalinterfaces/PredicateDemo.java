package com.oracle.inbuiltfunctionalinterfaces;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;

public class PredicateDemo {
	
	public static <T> void print(List<T> list,Predicate<T> predicate) {
		for(T t:list) {
			if(predicate.test(t)) {
				System.out.println(t);
			}
		}
	}

	public static void main(String[] args) {
		
		Predicate<String> predicateOfString1=(s)->{
			return s.isEmpty();
		};
		System.out.println("predicateOfString1->"+predicateOfString1.test("sabbir"));
		
		Predicate<String> predicateOfString2=String::isEmpty;
		System.out.println("predicateOfString2->"+predicateOfString2.test(" "));
		Object o=null;
		Predicate<Object> predicateOfObject=Objects::isNull;
		System.out.println("predicateOfObject->"+predicateOfObject.test(o));
		
		print(Arrays.asList(10,20,30),(element)->element>20);
		System.out.println("=================================");
		
		print(Arrays.asList("sabbir","amit","summet"),name->name.startsWith("a"));


		

	}

}










