package com.oracle.inbuiltfunctionalinterfaces;
@FunctionalInterface
public interface ExistingFactory {

	Existing create();
}
