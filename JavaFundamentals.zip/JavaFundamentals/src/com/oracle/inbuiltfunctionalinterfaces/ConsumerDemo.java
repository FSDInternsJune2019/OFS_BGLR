package com.oracle.inbuiltfunctionalinterfaces;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

public class ConsumerDemo {
	
	public static <T> void print(List<T> list,Consumer<T> consumer) {
		
		for(T t:list) {
			consumer.accept(t);
		}
	}

	public static void main(String[] args) {
		Consumer<String> consumerOfString1=s->{
			System.out.println(s.toUpperCase());
		};
		consumerOfString1.accept("sabbir");
		

		
		Consumer<String> consumerOfString2=new Existing()::lower;
		consumerOfString2.accept("SABBIR");
		
		Consumer<String> consumerOfString3=Existing::upper;
		consumerOfString3.accept("sabbir");
		
		
		ExistingFactory factory1=()->{
			return new Existing();
		};
		ExistingFactory factory=Existing::new;
		Existing object=factory.create();
		
		List<String> listOfString=new ArrayList<>();
		listOfString.add("sabbir");
		listOfString.add("amit");
		
		//1.
		Consumer<String> impl1=s->{
			System.out.println("impl1->"+s);
		};
		System.out.println("=========================");
		print(listOfString,impl1);
		System.out.println("=========================");

		print(listOfString,s->{
			System.out.println("impl2->"+s);
		});
		
		Consumer<String> c=System.out::println;
		System.out.println("=========================");

		print(listOfString,Existing::upper);
		System.out.println("=========================");

		print(listOfString,System.out::println);
		System.out.println("=========================");

		print(Arrays.asList(10,20,30),System.out::println);
		

	}

}


















