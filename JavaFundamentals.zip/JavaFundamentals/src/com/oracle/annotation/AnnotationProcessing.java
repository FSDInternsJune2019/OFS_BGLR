package com.oracle.annotation;

import java.lang.reflect.Method;

public class AnnotationProcessing {

	public static void main(String[] args) throws NoSuchMethodException, SecurityException {
		
		Class employeeClassData=Employee.class;
		OracleClass found=(OracleClass)employeeClassData.getAnnotation(OracleClass.class);
		if(found!=null) {
			System.out.println("--consider it as Oracle Class");
		}else {
			System.out.println("--Do not consider it as Oracle class");
		}

		Method xMethod=employeeClassData.getMethod("xMethod");
		OracleAuthor oracleAuthor=(OracleAuthor)xMethod.getAnnotation(OracleAuthor.class);
		if(oracleAuthor!=null) {
			System.out.println("Author Name:"+oracleAuthor.authorName());
			System.out.println("Date:"+oracleAuthor.date());
			System.out.println("Usage:"+oracleAuthor.usage());
		}else {
			System.out.println("Annotation not applied");
		}
	}

}
