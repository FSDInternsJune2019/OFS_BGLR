package com.oracle.entities;

public final class Immutable {

	private static int i;
	private int a;
	private int b;
	
	public Immutable() {}
	
	public Immutable(int a,int b){
		this.a=a;
		this.b=b;
	}
	//static initializer
	static {
		System.out.println("--Will be executed only once--");
		i=20;
	}
	//non-static initializer
	{
		System.out.println("--non-static initializer--");
	}
	
	public int getA(){
		return a;
	}

	public int getB() {
		return b;
	}
	@Override
	public String toString() {
		return "[immutable=a:"+a+","+"b:"+b+"]";
	}
	@Override
	public boolean equals(Object o) {
		if(o instanceof Immutable && o!=null) {
			Immutable immutable=(Immutable)o;
			if(this.a==immutable.a && this.b==immutable.b) {
				return true;
			}
		}
		return false;
	}
	@Override
	public int hashCode() {
		return a^b;
	}
}













