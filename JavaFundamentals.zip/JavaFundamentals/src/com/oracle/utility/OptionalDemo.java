package com.oracle.utility;

import java.util.Arrays;
import java.util.Optional;

public class OptionalDemo {
	/*
	public Integer sum(Integer o1,Integer o2) {
		if(o1==null && o2!=null) {
			return 0+o2.intValue();
		}else if(o1!=null && o2==null) {
			return o1.intValue()+0;
		}else if(o1==null && o2==null) {
			return 0+0;
		}
		return o1.intValue()+o2.intValue();
	}*/
	public Optional<Integer> sum(Optional<Integer> o1,Optional<Integer> o2){
		return Optional.of(o1.orElse(0)+o2.orElse(0));
	}

	public static void main(String[] args) {
		OptionalDemo o=new OptionalDemo();
		Optional<Integer> o1=Optional.ofNullable(null);
		Optional<Integer> o2=Optional.of(10);
		Optional<Integer> result=o.sum(o1, o2);
		if(result.isPresent())
			System.out.println(result.get());
	

	}

}
