package com.oracle.streams;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import java.util.Scanner;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class StreamCreationDemo {

	public static void main(String[] args) throws IOException {
		
		System.out.println("=========Arrays============");

		
		//1. Arrays
		
		int[] numbers= {23,45,67,89,21};
		
		OptionalInt max=Arrays
		.stream(numbers)
		.max();
		
		if(max.isPresent())
			System.out.println("Max:"+max.getAsInt());
		
		System.out.println("=========list============");

		
		//2. List
		List<Integer> numbersList=new ArrayList<>();
		numbersList.add(23);
		numbersList.add(45);
		numbersList.add(67);
		numbersList.add(89);
		numbersList.add(21);
		
		OptionalInt min=numbersList
		.stream()
		.mapToInt(Integer::intValue)
		.min();
		if(min.isPresent())
			System.out.println("Min:"+min.getAsInt());
		
		System.out.println("=========of============");

		//try with resources
		
		try(
		Scanner scanner=new Scanner(System.in);
		){
			System.out.print("No1:");
			int no1=scanner.nextInt();
			System.out.print("No2:");
			int no2=scanner.nextInt();
			System.out.print("No3:");
			int no3=scanner.nextInt();
			OptionalDouble average=
			Stream.of(no1,no2,no3)
			.mapToInt(Integer::intValue)
			.average();
			System.out.println("Average:"+average.getAsDouble());
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		System.out.println("=========distinct============");
		IntStream intStream=IntStream
		.builder()
		.add(13)
		.add(11)
		.add(11)
		.add(25)
		.build();
		
		intStream
		.distinct()
		.forEach(System.out::println);
		
		System.out.println("===========set====================");
		
		Set<Integer> setOfInteger=new HashSet<>();
		setOfInteger.add(10);
		setOfInteger.add(10);
		setOfInteger.add(30);
		setOfInteger.add(40);
		
		setOfInteger
		.stream()
		.mapToInt(Integer::intValue)
		.limit(3)
		.forEach(System.out::println);
		
		System.out.println("======================IO====================");
		BufferedReader buffer=
				new BufferedReader(new InputStreamReader
						(new FileInputStream("D:\\OFS\\data.txt")));
		Stream<String> lines=buffer.lines();
		lines.forEach(System.out::println);
		
		System.out.println("======================NIO====================");
		
		Path path=Paths.get("D:\\OFS\\data.txt");
		
		

		Stream<String> linesInNio= Files.lines(path);
	    linesInNio.map(String::toUpperCase)
	    .collect(Collectors.toList())
	    .forEach(System.out::println);
	    
		
	
		
		

	}

}







