package com.oracle.dynamic;

public class MyClass {
	
	public MyClass() {
		System.out.println("--MyClass--");
	}

	public void x() {
		System.out.println("--x--");
	}
}
