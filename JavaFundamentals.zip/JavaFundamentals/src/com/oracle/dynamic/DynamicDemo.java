package com.oracle.dynamic;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class DynamicDemo {

	public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {
		
		//static Initialization
		MyClass mc1=new MyClass();
		mc1.x();
		
		//dynamic Initialization
		
		ClassLoader cl=ClassLoader.getSystemClassLoader();
		Class myClassData=cl.loadClass("com.oracle.dynamic.MyClass");
		MyClass mc2=(MyClass)myClassData.newInstance();
		
		Method x=myClassData.getMethod("x");
		x.invoke(mc2);
		
		

	}

}
