package com.oracle.dynamic;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;

public class InvokeDynamic {

	public static void main(String[] args) throws Throwable {
		//newer api Invoke Dynamic
		MethodHandles.Lookup lookup=MethodHandles.lookup();
		MethodHandle x=lookup.findVirtual(MyClass.class, "x", MethodType.methodType(void.class));
		
		 MyClass dummy=new MyClass();
		Class<MyClass> myClassData=(Class<MyClass>) dummy.getClass();
		MyClass mc=(MyClass)myClassData.newInstance();
		
		x.invoke(mc);

	}

}
