package com.oracle.demo;

import com.oracle.entities.Immutable;
import com.oracle.entities.Mutable;

public class ImmutableMutableDemo {

	public static void main(String[] args) {
      Immutable immutableObject1=new Immutable(10,20);
      System.out.println("a:"+immutableObject1.getA());
      
      System.out.println(immutableObject1);
      
      Immutable immutableObject2=new Immutable(10,20);
      if(immutableObject1==immutableObject2)
    	  System.out.println("immutableObject1==immutableObject2");
      
      //equals() & ==
      String str1="Hello";
      String str2="Hello";
      if(str1==str2)
    	  System.out.println("str1==str2");
      
      String strObj1=new String("Hello");
      String strObj2=new String("Hello");
      
      if(strObj1==strObj2)
    	  System.out.println("strObj1==strObj2");
      if(strObj1.equals(strObj2))
    	  System.out.println("strObj1.equals(strObj2)");
      
      if(immutableObject1.equals(immutableObject1)) {
    	  System.out.println("immutableObject1.equals(immutableObject1)");
      }
      
      System.out.println("Hash code of immutableObject1:"+immutableObject1.hashCode());
      System.out.println("Hash code of immutableObject2:"+immutableObject2.hashCode());
      
      Mutable mutable=new Mutable();
      mutable.setA(10);
      mutable.setB(20);
      
     System.out.println(mutable);
     
     mutable.setB(30);
     System.out.println(mutable);

	}

}
