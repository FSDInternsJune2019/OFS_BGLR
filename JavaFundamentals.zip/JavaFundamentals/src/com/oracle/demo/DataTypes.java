package com.oracle.demo;
/**
 * @Author Sabbir Poonawala
 */

public class DataTypes {

	public static void main(String[] args) {
		// 8 -primitive data types in Java
		int i=10;//32-bits default 0  wrapper java.lang.Integer
		short s=20;//16-bits default 0 wrapper java.lang.Short
		long l=45L;//64-bits default 0L wrapper java.lang.Long
		float f=45.6F;// 32-bits default 0.0F wrapper java.lang.Float
		byte b=30;//8-bits default 0 wrapper java.lang.Byte
		char ch='A';//16-bits default '\u0000' wrapper java.lang.Character
		boolean flag=false;//1-bit default false wrapper java.lang.Boolean
		double d=22;//64-bits default 0D wrapper java.lang.Double
		
		int j=20;
		double promoteJ=j;//Implicitly promoted to higher data type
		
		double convertD=340D;
		int convertedInt=(int)convertD;//explictly convert double(higher) to int(lower);
		
		//wrapping primitive data into type of object--boxing
		Integer o=new Integer(10);
		
		//extracting primitive data back from object--unboxing
		int extract=o.intValue();
		
		//Java 5
		//Autoboxing
		Integer oAutobox=extract;
		
		//Autounboxing
		extract=oAutobox;
		
		
		
		
		

	}

}
