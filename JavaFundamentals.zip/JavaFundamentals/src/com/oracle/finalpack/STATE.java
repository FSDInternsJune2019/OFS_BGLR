package com.oracle.finalpack;

public enum STATE {
	ON(1),OFF(0),SUSPEND(2);
	
	private int val;
	private STATE(int val) {
		this.val=val;
	}
	
	public int getVal() {
		return val;
	}

}
