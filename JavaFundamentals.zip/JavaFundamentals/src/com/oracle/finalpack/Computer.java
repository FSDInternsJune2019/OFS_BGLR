package com.oracle.finalpack;

public class Computer {
	
	private int state;
	
	public void changeState(final STATE val) {
		
		switch(val) {
		case ON:
			       //switchOnComputer();
			break;
		case OFF:
			      //switchOffComputer();
			break;
		case SUSPEND:
			     //suspendComputer();
		
		}
		
	}
	

}
