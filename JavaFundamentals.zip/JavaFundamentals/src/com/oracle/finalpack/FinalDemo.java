package com.oracle.finalpack;

import com.oracle.annotation.Employee;

public class FinalDemo {

	public static void main(String[] args) {
		final int C=100;
		final int K=104;
		final int M=C+K;
		//C=101;//error
		
		final Employee e=new Employee();
		e.setEmpId(1001);
		//e=new Employee();//error
		
		Computer computer=new Computer();
		computer.changeState(1);//error
		computer.changeState(-1);//error
		computer.changeState(STATE.ON);

	}

}
