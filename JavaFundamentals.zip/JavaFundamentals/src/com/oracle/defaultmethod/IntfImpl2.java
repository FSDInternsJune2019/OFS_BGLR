package com.oracle.defaultmethod;

public class IntfImpl2 implements Intf {

	
	public void y() {
		this.x();
		Intf.super.x();
	}
}
