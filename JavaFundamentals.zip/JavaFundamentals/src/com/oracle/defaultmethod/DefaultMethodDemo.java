package com.oracle.defaultmethod;

import java.util.Arrays;

public class DefaultMethodDemo {

	public static void main(String[] args) {
		Intf intf=new IntfImpl1();
		intf.x();
		intf=new IntfImpl2();
		intf.x();
		
		IntfImpl2 impl2=new IntfImpl2();
		impl2.y();
		
		Arrays.asList(100,200,300).forEach(System.out::println);

	}
}
