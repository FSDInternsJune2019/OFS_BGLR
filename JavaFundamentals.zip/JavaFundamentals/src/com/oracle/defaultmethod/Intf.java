package com.oracle.defaultmethod;

public interface Intf {

	default void x() {
		System.out.println("--Default implementation--");
	}
}
