package com.oracle.defaultmethod;

public class IntfImpl1 implements Intf {

	@Override
	public void x() {
		System.out.println("--Impl1--");
	}
}
