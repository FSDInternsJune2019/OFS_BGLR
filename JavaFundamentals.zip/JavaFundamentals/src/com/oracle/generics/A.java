package com.oracle.generics;

public class A {

}
