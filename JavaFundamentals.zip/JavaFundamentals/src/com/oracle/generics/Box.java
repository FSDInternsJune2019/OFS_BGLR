package com.oracle.generics;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Box<T> {
	
	private T data;
	
	public void setData(T data) {
		this.data=data;
	}
	
	public T getData() {
		return data;
	}
	/*
	public static  void print(List<?> list) {
		list.forEach(System.out::println);
	}*/

	//upper boundary// subtypes Number and Subclass of Number objects
	public static void print(List<? extends Number> list) {
		list.forEach(System.out::println);
	}
	//lower boundary //supertypes // Super class of String
	public static void print(Set<? super C> set) {
		set.forEach(System.out::println);
	}
	
}











