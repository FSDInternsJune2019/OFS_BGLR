package com.oracle.generics;

public class C extends B {

}
