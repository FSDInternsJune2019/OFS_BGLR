package com.oracle.generics;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class BoxDemo {

	public static void main(String[] args) {
		
		Box<String> boxOfString=new Box<>();
		boxOfString.setData("sabbir");
		//boxOfString.setData(10); error
	
		String data=boxOfString.getData();
		
		Box.print(Arrays.asList(10,12.F,101D));
		Set<A> setOfA=new HashSet<>();
		setOfA.add(new B());
		setOfA.add(new A());
		
		Box.print(setOfA);
	}

}
