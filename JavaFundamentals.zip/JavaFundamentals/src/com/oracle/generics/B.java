package com.oracle.generics;

public class B extends A{

}
