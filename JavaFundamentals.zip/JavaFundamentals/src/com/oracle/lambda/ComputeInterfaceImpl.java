package com.oracle.lambda;

public class ComputeInterfaceImpl implements ComputeInterface {

	@Override
	public double compute(double a, double b) {
		return a+b;
	}
	
	class InnerComputeInterfaceImpl implements ComputeInterface{

		@Override
		public double compute(double a, double b) {
			// TODO Auto-generated method stub
			return a-b;
		}
		
	}
	
	public static void main(String args[]) {
		ComputeInterfaceImpl outer=new ComputeInterfaceImpl();
		System.out.println("outer->"+outer.compute(10, 20));
		
		ComputeInterfaceImpl.InnerComputeInterfaceImpl inner=
				outer.new InnerComputeInterfaceImpl();
		System.out.println("inner->"+inner.compute(10, 20));
		
		ComputeInterface annoymous=new ComputeInterface() {
        	@Override
			public double compute(double a, double b) {
				return a*b;
			}
		};
		System.out.println("annoymous->"+annoymous.compute(10, 20));
		
		ComputeInterface impl1=(a,b)->{
			return a+b;
		};
		
		System.out.println("impl1->"+impl1.compute(10, 20));
		
		ComputeInterface impl2=(a,b)->a-b;
		System.out.println("impl2->"+impl2.compute(10, 20));

	}

}











