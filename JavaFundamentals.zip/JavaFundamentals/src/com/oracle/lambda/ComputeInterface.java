package com.oracle.lambda;
@FunctionalInterface
public interface ComputeInterface {
	
	public double compute(double a,double b);

}
