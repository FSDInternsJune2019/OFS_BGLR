package com.oracle.lambda;

public class NonCapturingLamdba {

	public static void main(String[] args) {

		
		Runnable r=()->{
			String name="sabbir";
			System.out.println("Worker Thread:"+name.toUpperCase());
		};
		
		Thread worker=new Thread(r,"Worker-1");
		worker.start();

	}

}
