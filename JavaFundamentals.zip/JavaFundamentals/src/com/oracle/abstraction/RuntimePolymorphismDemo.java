package com.oracle.abstraction;

public class RuntimePolymorphismDemo {

	public static void main(String[] args) {
		Figure figRef=null;
		figRef=new Rectangle(34,40);
		figRef.area();
		
		figRef=new Square(30);
		figRef.area();  //late binding, runtime polymorphism
		
		Square s=new Square(10);//static binding
		s.area();

	}

}
