package com.oracle.abstraction;

public class InterfaceDemo {

	public static void main(String[] args) {
		Intf intf=new IntfImpl1();
		intf.x1();
		intf.x2();
		
		

	}

}
