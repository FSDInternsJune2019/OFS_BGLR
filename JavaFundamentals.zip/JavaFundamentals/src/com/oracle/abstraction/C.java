package com.oracle.abstraction;

public interface C {
  void c();
}
