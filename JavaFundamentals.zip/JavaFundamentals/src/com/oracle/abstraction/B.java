package com.oracle.abstraction;

public interface B {
  void b();
}
