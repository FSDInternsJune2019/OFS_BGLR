package com.oracle.abstraction;

public class Square extends Figure{
	
	private double length;
	
	public Square(double length) {
		super();
		this.length = length;
	
	}

	@Override
	public double area() {
		
		return length*length;
	}
	
	

}
