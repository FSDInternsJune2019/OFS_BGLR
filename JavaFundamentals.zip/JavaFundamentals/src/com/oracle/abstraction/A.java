package com.oracle.abstraction;

public interface A extends B,C {
  void a();
}
