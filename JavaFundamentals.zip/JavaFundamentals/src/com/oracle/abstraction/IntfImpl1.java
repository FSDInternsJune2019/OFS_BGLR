package com.oracle.abstraction;

public class IntfImpl1 implements Intf {

	@Override
	public void x1() {
		System.out.println("--x1--");
		
	}

	@Override
	public void x2() {
		System.out.println("--x2--");
		
	}

}
