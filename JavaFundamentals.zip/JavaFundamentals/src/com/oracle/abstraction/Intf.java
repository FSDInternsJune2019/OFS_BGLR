package com.oracle.abstraction;

public interface Intf {
	
	int K=10;
	void x1();
	void x2();

}
