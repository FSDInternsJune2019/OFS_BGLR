package com.demo.entities;

import java.util.Objects;

public class Mutable {
	
	public Mutable() {}
	
	private int a;
	private int b;
	
	public void setA(int a) {
		this.a=a;
	}
	public int getA() {
		return a;
	}
	public int getB() {
		return b;
	}
	public void setB(int b) {
		this.b = b;
	}
	@Override
	public int hashCode() {
		return Objects.hash(a, b);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Mutable other = (Mutable) obj;
		return a == other.a && b == other.b;
	}
	@Override
	public String toString() {
		return "Mutable [a=" + a + ", b=" + b + "]";
	}
	@Deprecated
	/**
	 * @see new_x()
	 */
	public void x() {
		
	}
	public void new_x() {
		
	}
	

}
