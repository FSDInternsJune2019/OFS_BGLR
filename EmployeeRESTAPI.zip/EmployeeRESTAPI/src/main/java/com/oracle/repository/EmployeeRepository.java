package com.oracle.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.oracle.entities.Employees;

@Repository
public interface EmployeeRepository extends CrudRepository<Employees,Integer> {
}
