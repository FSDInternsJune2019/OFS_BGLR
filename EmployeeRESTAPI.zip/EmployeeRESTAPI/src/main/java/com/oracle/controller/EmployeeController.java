package com.oracle.controller;

import org.springframework.http.ResponseEntity;

public interface EmployeeController {
	
	public ResponseEntity<?> get();

}
