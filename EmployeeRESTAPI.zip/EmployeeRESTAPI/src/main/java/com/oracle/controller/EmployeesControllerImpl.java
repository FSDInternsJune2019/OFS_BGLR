package com.oracle.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oracle.dto.EmployeesDTO;
import com.oracle.service.EmployeesService;

@RestController
@RequestMapping("api")
public class EmployeesControllerImpl implements EmployeeController{
	@Autowired
	private EmployeesService employeesService;

	@GetMapping("employees")
	@Override
	public ResponseEntity<?> get() {
		List<EmployeesDTO> employeesDTO=employeesService.getEmployeesDTO();
		if(!employeesDTO.isEmpty()) {
			return new ResponseEntity<List<EmployeesDTO>>(employeesDTO,HttpStatus.OK);
		}
		return new ResponseEntity<String>("No resource found",HttpStatus.NOT_FOUND);
	}

}







