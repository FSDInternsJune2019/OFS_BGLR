package com.oracle.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.oracle.dto.EmployeesDTO;
import com.oracle.entities.Employees;
import com.oracle.repository.EmployeeRepository;

@Service
public class EmployeesServiceImpl implements EmployeesService{
	@Autowired
	private EmployeeRepository employeeRepository;

	@Override
	public List<EmployeesDTO> getEmployeesDTO() {
		
		Iterable<Employees> employeesList=employeeRepository.findAll();
		List<EmployeesDTO> employeesDTOList=new ArrayList<>();
		for(Employees employees:employeesList) {
			EmployeesDTO employeesDTO=new EmployeesDTO();
			employeesDTO.setEmpId(employees.getEmpId());
			employeesDTO.setEmpName(employees.getEmpName());
			employeesDTO.setEmpSalary(employees.getEmpSalary());
			employeesDTO.setEmpDesignation(employees.getEmpDesignation());
			employeesDTOList.add(employeesDTO);
		}
		return employeesDTOList;
	}

}
