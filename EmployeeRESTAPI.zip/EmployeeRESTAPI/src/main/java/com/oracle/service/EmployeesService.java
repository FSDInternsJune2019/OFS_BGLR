package com.oracle.service;

import java.util.List;

import com.oracle.dto.EmployeesDTO;

public interface EmployeesService {
	
	public List<EmployeesDTO> getEmployeesDTO();

}
