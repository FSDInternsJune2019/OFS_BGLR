package com.oracle.dto;

import lombok.Data;

@Data
public class EmployeesDTO {
	
	private int empId;
	private String empName;
	private double empSalary;
	private String empDesignation;
	
	public EmployeesDTO() {}
	
	

}
